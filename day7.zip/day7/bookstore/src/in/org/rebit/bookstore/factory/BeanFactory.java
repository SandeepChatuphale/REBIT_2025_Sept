package in.org.rebit.bookstore.factory;

import com.mysql.cj.jdbc.Driver;
import in.org.rebit.bookstore.dao.BookDao;
import in.org.rebit.bookstore.dao.impl.BookCollectionDaoImpl;
import in.org.rebit.bookstore.dao.impl.BookJdbcDaoImpl;
import in.org.rebit.bookstore.service.BookService;
import in.org.rebit.bookstore.service.impl.BookServiceImpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class BeanFactory {

    public Connection getConnection() throws SQLException {
        Connection c = getDriver().connect("",null);
        return c;
    }

    public Driver getDriver() throws SQLException {
        Driver d = new Driver();
        System.out.println("=========");
        System.out.println(d.acceptsURL("jdbc:mssql://localhost:3306/"));

        return d;
    }




    public BookDao getBookDao(){

        BookJdbcDaoImpl dao = new BookJdbcDaoImpl();
        return dao;
    }

    public BookService getBookService()
    {
        BookServiceImpl service = new BookServiceImpl(getBookDao());
        //service.setDao(getBookDao());//DI
        return service;
    }

}
