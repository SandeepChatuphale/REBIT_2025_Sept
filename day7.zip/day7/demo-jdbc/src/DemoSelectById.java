import java.sql.*;

public class DemoSelectById {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        Class.forName("com.mysql.jdbc.Driver");
        Connection con;

        //jdbc url - protocol:subprotocol:dns
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/"
                ,"root"
                ,"root");
        PreparedStatement ps;
        String sql = "SELECT * FROM bookstore_db.tbl_book WHERE id = 1";
        ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        if(rs.next()){
            System.out.println(rs.getInt(1));
            System.out.println(rs.getString(2));
            System.out.println(rs.getString(3));
            System.out.println(rs.getDouble(4));
        }




    }
}
