import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DemoSave {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        Connection con;

        //jdbc url - protocol:subprotocol:dns
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/"
                ,"root"
                ,"root");

        PreparedStatement ps;
        String sql = "INSERT INTO bookstore_db.tbl_book VALUES(1,'java','kathy',200)";
        ps = con.prepareStatement(sql);
        //depending on query following step changes
        int numberOfRowsInserted = ps.executeUpdate();
        System.out.println(numberOfRowsInserted);

        ps.close();
        con.close();
    }
}
