import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-sort-rooms',
  standalone: true,
  imports: [],
  templateUrl: './sort-rooms.component.html',
  styleUrl: './sort-rooms.component.css'
})
export class SortRoomsComponent {

  @Output()
  criteriaEmitter = new EventEmitter<string>();
  
  sortCriteriaSelected(type:string){
    //emit will update parent component
    this.criteriaEmitter.emit(type);

  }


}
