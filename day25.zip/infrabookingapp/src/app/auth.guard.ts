import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { EmployeeService } from './service/employee.service';

export const authGuard: CanActivateFn = (route, state) => {

  const service = inject(EmployeeService);
  if(service.isAuthenticated())
  {
    return true;
  }
  else{
    const r = inject(Router);
    r.navigate(['unauthorized'])
    return false;
  }

};
