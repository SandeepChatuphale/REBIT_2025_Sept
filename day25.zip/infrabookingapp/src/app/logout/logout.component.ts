import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../service/employee.service';

@Component({
  selector: 'app-logout',
  standalone: true,
  imports: [],
  templateUrl: './logout.component.html',
  styleUrl: './logout.component.css'
})
export class LogoutComponent {

  constructor(private r : Router,private service : EmployeeService){}

  logout():void{
    const result =  confirm('are you sure?');
    if(result)
    {
      this.service.invalidateSession();
      this.r.navigate(['login'],
        {queryParams:{success:'Logged out successfully'}})
    }
  }
}
