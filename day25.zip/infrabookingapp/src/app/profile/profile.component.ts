import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../service/employee.service';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [ReactiveFormsModule,CommonModule],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent implements OnInit {
    username : string = '';
    profileForm : FormGroup = new FormGroup({
      oldpassword: new FormControl('',[Validators.required,
                                       Validators.minLength(4),
                                       Validators.maxLength(15)])
    });

    constructor(private service : EmployeeService){
      this.username = this.service.authentication.email;
    }
  ngOnInit(): void {
    this.service.findProfileByEmail('sandeepc@gmail.com');
  }
  updateProfile(e:Event) : void{
    e.preventDefault();//preventing form submission event to avoid
                       //reloading page
    console.log(this.profileForm) //printing FormGroup Object
                            //to check built-in properties
                            //which we will use for fetching values,
                            //validation

    console.log(this.profileForm.getRawValue())//prints value of 
      //all the FormControls present in this FormGroup
  }

  get f(){
    return this.profileForm.controls
  }

}
