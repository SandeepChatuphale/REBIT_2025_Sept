import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  standalone: true,
  imports: [],
  templateUrl: './child.component.html',
  styleUrl: './child.component.css'
})
export class ChildComponent {

  @Input()
  data : string = '';

  @Output()
  dataEmitter = new EventEmitter<number>();

  countLength(){
    const lengthOfData = this.data.length;
    this.dataEmitter.emit(lengthOfData)
    
  }

}
