import { Component } from '@angular/core';
import { ChildComponent } from '../child/child.component';

@Component({
  selector: 'app-parent',
  standalone: true,
  imports: [ChildComponent],
  templateUrl: './parent.component.html',
  styleUrl: './parent.component.css'
})
export class ParentComponent {
  company : string = 'ReBIT'

  accept(){
    this.company = 'mumbai is beautiful city'
  }
  //child will invoke this method
  dataFromChild(l : number){
    alert('parent is saying length is ' + l)
  }
}
