import { Injectable } from '@angular/core';
import { Room } from '../../dto/room';

@Injectable({
  providedIn: 'root'
})
export class RoomService {
  private rooms : Room[] = [];
  constructor() {
     let r1 = new Room(1,'Meeting',12,true);
      let r2 = new Room(2,'Meeting',20,true);
      let r3 = new Room(3,'Interview',22,false);
      let r4 = new Room(4,'Training',12,true);
      this.rooms.push(r1);
      this.rooms.push(r2);
      this.rooms.push(r3);
      this.rooms.push(r4);
   }
  findAllRooms() : Room[]{
      return this.rooms;
  }
  createNewRoom(r:Room){
    r.id = this.rooms.length  + 1;
    this.rooms.push(r);
  }
}
