import { Injectable } from '@angular/core';
import { Employee } from '../../dto/Employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private authenticated : boolean = false;
  private employees : Employee[] = [];
  public authentication  = new Employee();

  constructor() { }
  
  registerEmployee(e : Employee){
    this.employees.push(e);
  }
  
  login(e : Employee) : boolean {
    for(let foundEmployee of this.employees){
      if(foundEmployee.email == e.email && foundEmployee.password == e.password)
        this.authenticated = true;
        this.authentication.email = foundEmployee.email;
        this.authentication.password = ''
        return true;
    }
    return false;
  }

  isAuthenticated() : boolean{
    return this.authenticated;
  }

  invalidateSession():boolean{
    this.authenticated = false;
    this.authentication = new Employee();
    return this.authenticated;
  }
}
