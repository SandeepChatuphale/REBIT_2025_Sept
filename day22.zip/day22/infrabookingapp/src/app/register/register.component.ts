import { Component } from '@angular/core';
import { EmployeeService } from '../service/employee.service';
import { Employee } from '../../dto/Employee';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {

  //
  email:string = '';
  password:string = '';

  constructor(private service : EmployeeService){}

  performRegistration(){
      const e = new Employee(this.email,this.password);
      this.service.registerEmployee(e)
  }

}
