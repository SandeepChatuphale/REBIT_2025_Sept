import { Component } from '@angular/core';
import { Room } from '../../dto/room';
import { CommonModule } from '@angular/common';
import { RoomService } from '../service/room.service';
import { SortRoomsComponent } from '../sort-rooms/sort-rooms.component';
import { UpdateroomComponent } from '../updateroom/updateroom.component';

@Component({
  selector: 'app-rooms',
  standalone: true,
  imports: [CommonModule,SortRoomsComponent,UpdateroomComponent],
  templateUrl: './rooms.component.html',
  styleUrl: './rooms.component.css'
})
export class RoomsComponent {
  rooms : Room[] = [];
  roomTobeUpdated = new Room(0,'',0,false);
  
  //used in template
  showUpdateForm : boolean = false
  message :string = ''
  isDeleted = false;
  messageColor = '';
  styles = {'color':'red','fontSize':'40px'}
  boxCss = 'box';
  //successColor- is a name of css class as defined in .css file
  successColorName : string = 'successColor';
  color:string=''
  //DI- injecting RoomService Object
  constructor(private service:RoomService ){}
  showAllRooms() : void {
    this.rooms = this.service.findAllRooms();
  }
  //this is invoked by RoomsComponent
  updateRoom(r:Room){
    this.showUpdateForm = true;
    this.roomTobeUpdated = r;
  }
  //this is invoked by child component
  updateRoomDone(updatedRoom:Room){
    this.showUpdateForm = false
    for(let r of this.rooms){
      if(r.id == updatedRoom.id){
        r.type = updatedRoom.type
        r.available = updatedRoom.available
        r.capacity = updatedRoom.capacity
      }
    }
  }

  deleteRoomById(id:number):void{
      const result =  confirm('are you sure?');
      if(result){
          this.rooms = this.rooms.filter( r => r.id != id )
         
          //for GUI
          this.message = 'Room with id ' + id +' is deleted ';
          this.isDeleted = true;
          this.messageColor = 'red';
          this.styles.color = 'red'
          this.successColorName = 'successColor'
          
      }
      else{
        this.message = 'Cancelled'
        this.isDeleted = false
        this.messageColor = 'green';
        this.styles.color = 'green'
        this.successColorName = 'errorColor'
      }
  }
  sortRooms(sortType:string){
    
    if(sortType == 'asc')
      this.rooms = this.rooms.sort( (r1,r2) => r1.capacity - r2.capacity  );
    else
      this.rooms = this.rooms.sort( (r1,r2) => r2.capacity - r1.capacity  );

  }
}
