import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Employee } from '../../dto/Employee';
import { EmployeeService } from '../service/employee.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {

  //
  email:string = '';
  password:string = '';

  //used in template to update GUI
  message=''
  isValid : boolean = false;

  constructor(private service : EmployeeService,
              private r : Router,
              private route : ActivatedRoute){}

ngOnInit(): void {
    //fetch query params
    this.route.queryParams.subscribe( params => 
      this.message = params['success'] )
}

  performLogin(){
    let e = new Employee(this.email,this.password)
    const result = this.service.login(e);
    if(result)
    {
      this.r.navigate(['rooms'])
      this.message = "login Success";
    }
    else{
      this.message = "bad credentials"
    }
  }

 


}
