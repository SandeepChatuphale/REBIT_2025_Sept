import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { EmployeeService } from '../service/employee.service';

@Component({
  selector: 'app-menu',
  standalone: true,
  imports: [CommonModule,RouterModule],
  templateUrl: './menu.component.html',
  styleUrl: './menu.component.css'
})
export class MenuComponent {

  username : string = 'Guest User';
  today = new Date();

  constructor(private service : EmployeeService){}

  isLoggedIn() : boolean{
    this.username = this.service.authentication.email;
    return this.service.isAuthenticated();
  }
}
