import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SortRoomsComponent } from './sort-rooms.component';

describe('SortRoomsComponent', () => {
  let component: SortRoomsComponent;
  let fixture: ComponentFixture<SortRoomsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SortRoomsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SortRoomsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
