import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Room } from '../../dto/room';

@Component({
  selector: 'app-updateroom',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './updateroom.component.html',
  styleUrl: './updateroom.component.css'
})
export class UpdateroomComponent implements OnInit,OnChanges,OnDestroy {
  ngOnDestroy(): void {
    console.log('in ngOnDestroy')
  }
  
  
  type:string='';
  capacity:number = 0;
  available:boolean=false

  //input from parent component
  @Input()
  selectedRoom = new Room(0,'',0,false);

  formRoom = new Room(0,'',0,false)

  @Output()
  updateRoomEmitter = new EventEmitter<Room>();

  ngOnInit(): void {
    console.log('in on ngOninit=====')
  }
  ngOnChanges(changes: SimpleChanges): void {
   
    this.formRoom.id = this.selectedRoom.id;
    this.formRoom.available = this.selectedRoom.available
    this.formRoom.type = this.selectedRoom.type
    this.formRoom.capacity = this.selectedRoom.capacity
  }
  updateRoom(){
    this.updateRoomEmitter.emit(this.formRoom);
  }
}
