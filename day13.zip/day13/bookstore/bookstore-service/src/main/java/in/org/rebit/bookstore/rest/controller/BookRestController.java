package in.org.rebit.bookstore.rest.controller;

import in.org.rebit.bookstore.entity.Book;
import in.org.rebit.bookstore.exception.BookNotFoundException;
import in.org.rebit.bookstore.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/book")
public class BookRestController {

    @Autowired
    private BookService service;

    @GetMapping("/{id}")
    public Book getById(@PathVariable int id) throws BookNotFoundException {
        return  this.service.searchBookById(id);
    }

    @GetMapping(value = "/{id}",params = "full")
    public Book getFullBookById(@PathVariable int id) throws BookNotFoundException {
        return this.service.searchFullBookById(id);
    }


}
