package in.org.rebit.bookstore.service.impl;

import in.org.rebit.bookstore.dao.BookDao;

import in.org.rebit.bookstore.entity.Book;
import in.org.rebit.bookstore.exception.BookNotFoundException;
import in.org.rebit.bookstore.feign.client.BookFeignClient;
import in.org.rebit.bookstore.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookServiceImpl implements BookService {

    @Autowired
    private BookFeignClient client;

    //coding to interface
    @Autowired
    private BookDao dao;

    @Override
    public Book registerNewBook(Book bookToBeRegistered) {
        return this.dao.save(bookToBeRegistered);
    }

    @Override
    public List<Book> searchAllBooks() {
        return this.dao.findAll();
    }

    @Override
    public Book searchBookById(int id) throws BookNotFoundException {

        Optional<Book> o = this.dao.findById(id);
        return o.orElseThrow(() -> new BookNotFoundException("Book with id " + id +" NOT Found"));

        /*if(o.isPresent()) {
            Book foundBook = o.get();
            return foundBook;
        }
        else
            throw new BookNotFoundException("Book with id " + id +" NOT Found");*/
    }

    @Override
    public Book updateBook(int id,double newPrice) throws BookNotFoundException {
        Book bookToBeUpdated = searchBookById(id);
        bookToBeUpdated.setPrice(newPrice);
        return bookToBeUpdated;
    }

    @Override
    public boolean deleteBookById(int id) throws BookNotFoundException {
         this.dao.deleteById(id);
        return true;
    }

    @Override
    public Book searchFullBookById(int id) throws BookNotFoundException {
        Book foundBook = this.searchBookById(id);
        //make rest call to author-service
        String authorName = client.findAuthorNameById(foundBook.getAuthorId());
        foundBook.setAuthorName(authorName);
        return foundBook;
    }
}
