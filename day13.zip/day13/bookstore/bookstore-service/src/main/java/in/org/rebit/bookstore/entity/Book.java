package in.org.rebit.bookstore.entity;


import jakarta.persistence.*;

@Entity
@Table(name = "tbl_book")
public class Book implements Comparable<Book> {

    //instance variables
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    @Column(nullable = false)
    private String title;
    private double price;
    private int authorId;

    @Transient
    private String authorName;

    public Book() {}

    public Book(String title, int authorId, double price) {
        this.title = title;
        this.authorId = authorId;
        this.price = price;
    }
    public Book(int id,String title, int author, double price) {
        this.id = id;
        this.title = title;
        this.authorId = authorId;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getAuthorId() {
        return authorId;
    }

    public void setAuthorId(int authorId) {
        this.authorId = authorId;
    }

    @Override
    public int compareTo(Book o) {
        return (int) (this.price - o.price);
    }

}
