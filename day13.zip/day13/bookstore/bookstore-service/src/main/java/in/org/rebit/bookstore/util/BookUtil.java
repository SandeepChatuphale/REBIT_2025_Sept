package in.org.rebit.bookstore.util;
import in.org.rebit.bookstore.entity.Book;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class BookUtil {

    //multiple methods for different criteria
    public static void sortBooksByPrice(List<Book> books){
        Collections.sort(books);
    }
    public static void sortBooksByTitle(List<Book> books){
        Collections.sort(books,new BookComparisonByTitle());
    }

    //generic method can sort books on any criteria
    //passed to it using lambda function
    public static void sortBooks(List<Book> books,Comparator<Book> c) {
        Collections.sort(books, c);
    }

    //client wants to support following feature-
    //application should create partition of existing books based on price-
    //imperative style of programming
    public static Map<Boolean,List<Book>> partitionBooksByPrice(List<Book> books,double price)
    {
        Map<Boolean,List<Book>> pm = books.stream()
                .collect(Collectors.partitioningBy(b -> b.getPrice()>price));

        //create a Map object
        Map<Boolean,List<Book>> partitionedMap = new HashMap<>();
        //create 2 List Objects
        List<Book> lower = new ArrayList<>();
        List<Book> higher = new ArrayList<>();
        //iterate over passed books list
        for(Book b : books)
        {
            //check condition
            //add in respective list object
            if(b.getPrice() > price){
                higher.add(b);
            }
            else
                lower.add(b);
        }
        //add in map
        partitionedMap.put(true,higher);
        partitionedMap.put(false,lower);
        //return map
        return partitionedMap;
    }
    public static List<Book> searchBooksByCriteria(List<Book> books, Predicate<Book> p){
        return books.stream()
                .filter(p)
                .toList();
    }
    /*
    public static List<Book> searchBooksByAuthor(List<Book> books,String name){
        return books.stream()
                    .filter(b -> b.getAuthor().startsWith(name))
                    .toList();
    }
    public static List<Book> searchBooksByLessThanPrice(List<Book> books,double price){
        return books.stream()
                .filter(b -> b.getPrice()<price)
                .toList();
    }
    public static List<Book> searchBooksByGreaterThanPrice(List<Book> books,double price){
        return books.stream()
                .filter(b -> b.getPrice() > price)
                .toList();
    }
    */


    public static long countOfBooksByCriteria(List<Book> books,Predicate<Book> p){
        return books.stream()
                .filter(p)
                .count();
    }

    public static List<String> searchAuthors(List<Book> books){
        return books.stream()
                .map(b -> b.getAuthorName())
                .toList();  //added in JDK 16
                //.collect(Collectors.toList());
    }

    public static Set<String> searchUniqueAuthors(List<Book> books){
        return books.stream()
                .map(b -> b.getAuthorName())
                .collect(Collectors.toSet());
    }










    public static Map<Double,List<Book>> groupBy(List<Book> books)
    {
        //JDK 8 approach
        Map<Double,List<Book>> mm1 = books.stream().collect(Collectors.groupingBy(b -> b.getPrice()));
        System.out.println(mm1);
        //priorJDK 8 approach
        Map<Double,List<Book>> mm = new HashMap<>();
        //List<Book> booksGroup = new ArrayList<>();
        for(Book b : books)
        {
            List<Book> li = new ArrayList<>();
            li.add(b);

            mm.put(b.getPrice(),li);
        }
        System.out.println(mm);

        return mm;
    }



    public static Map<Boolean,List<Book>> partitioningBy(List<Book> books)
    {
        //JDK 8 approach
        Map<Boolean, List<Book>> mm = books.stream().collect(Collectors.partitioningBy(p -> p.getPrice()>50));


        //priorJDK 8 approach
        Map<String,List<Book>> group = new HashMap<>();

        List<Book> cheap = new ArrayList<>();
        List<Book> costly = new ArrayList<>();

        for (Book b : books)
        {
            if(b.getPrice() < 50){
                cheap.add(b);
            }
            else {
                costly.add(b);
            }
        }
        group.put("cheap",cheap);
        group.put("costly",costly);

        return mm;
    }
}