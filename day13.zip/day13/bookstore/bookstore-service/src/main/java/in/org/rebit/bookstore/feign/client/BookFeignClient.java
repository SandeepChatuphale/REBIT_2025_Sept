package in.org.rebit.bookstore.feign.client;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

public interface BookFeignClient {

    @GetMapping("/author/{id}")
    String findAuthorNameById(@PathVariable int id);
}
