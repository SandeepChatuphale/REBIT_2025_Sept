import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Room } from '../../dto/room';
import { RoomService } from '../service/room.service';

@Component({
  selector: 'app-createroom',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './createroom.component.html',
  styleUrl: './createroom.component.css'
})
export class CreateroomComponent {

  type:string='';
  capacity:number = 0;
  available:boolean=false
  constructor(private service:RoomService){}
  createNewRoom() : void{
    let roomTobeCreated = new Room(0,this.type,this.capacity,this.available);
  
    //insert this object to rooms array defined in RoomsComponent
    this.service.createNewRoom(roomTobeCreated);

  }

}
