import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RoomsComponent } from './rooms/rooms.component';
import { CreateroomComponent } from './createroom/createroom.component';
import { RegisterComponent } from './register/register.component';
import { LogoutComponent } from './logout/logout.component';
import { authGuard } from './auth.guard';
import { UnauthorizedComponent } from './unauthorized/unauthorized.component';
import { ProfileComponent } from './profile/profile.component';

export const routes: Routes = [
    {path:'login',component:LoginComponent},
    {path:'profile/:email',component:ProfileComponent},
    {path:'register',component:RegisterComponent},
    {path:'logout',component:LogoutComponent},

    {path:'rooms',component:RoomsComponent,canActivate:[authGuard]},
    {path:'createroom',component:CreateroomComponent,canActivate:[authGuard]},
    
    {path:'unauthorized',component:UnauthorizedComponent},
    {path:'**',redirectTo:'login'},
];
