import { Injectable } from '@angular/core';
import { Room } from '../../dto/room';
import { HttpClient, HttpHandler, HttpHeaders } from '@angular/common/http';
import { EmployeeService } from './employee.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RoomService {
  private rooms : Room[] = [];
  constructor(private http:HttpClient,private service:EmployeeService) {}

  findAllRooms() : Observable<Room[]>{
    let headers = new HttpHeaders();
    headers = headers.append("Authorization","Bearer " + 
      this.service.getToken());
    return this.http.get<Room[]>('http://localhost/room-service/rooms',
      {headers});
  }
  createNewRoom(r:Room){
    r.id = this.rooms.length  + 1;
    this.rooms.push(r);
  }
}
