export class Room{
    constructor(public id:number,
                public type:string,
                public capacity:number,
                public available:boolean){}
}