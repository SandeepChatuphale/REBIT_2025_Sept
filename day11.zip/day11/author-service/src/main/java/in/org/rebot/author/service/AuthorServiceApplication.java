package in.org.rebot.author.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthorServiceApplication {

	public static void main(String[] args) {

		SpringApplication.run(AuthorServiceApplication.class, args);
	}

}
