import in.org.rebit.bookstore.entity.Book;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;


public class DemoSave {
    public static void main(String[] args) {

        EntityManagerFactory factory ;
        factory = Persistence.createEntityManagerFactory("bookUnit");

        System.out.println(factory.getClass());


        EntityManager em;
        em = factory.createEntityManager();
        System.out.println(em.getClass());

        Book b = new Book(3,"SE","Pressman",30);

        EntityTransaction tx ;
        tx = em.getTransaction();
        tx.begin();
        //DB operation
        em.persist(b);  //insert record in DB

        tx.commit();
        em.close();
        factory.close();





    }
}
