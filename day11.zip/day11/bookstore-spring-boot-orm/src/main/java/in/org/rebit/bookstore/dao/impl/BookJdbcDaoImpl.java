package in.org.rebit.bookstore.dao.impl;

import in.org.rebit.bookstore.dao.BookDao;
import in.org.rebit.bookstore.entity.Book;

import java.sql.*;
import java.util.List;
import java.util.Optional;

public class BookJdbcDaoImpl implements BookDao {

    private Connection con;
    private PreparedStatement ps;

    public BookJdbcDaoImpl(){
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/"
                    , "root"
                    , "root");
        }
        catch (ClassNotFoundException | SQLException e){
            e.printStackTrace();
        }
    }

    public void close(){
        System.out.println("===closing resources=====");
    }


    @Override
    public boolean save(Book bookToBeSaved) {
        try {
            String sql = "INSERT INTO bookstore_db.tbl_book VALUES(?,?,?,?)";
            ps = con.prepareStatement(sql);
            ps.setInt(1,bookToBeSaved.getId());
            ps.setString(2,bookToBeSaved.getTitle());
            ps.setString(3,bookToBeSaved.getAuthor());
            ps.setDouble(4,bookToBeSaved.getPrice());
            int numberOfRowsInserted = ps.executeUpdate();
            return numberOfRowsInserted == 1;
        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public Optional<Book> findById(int id) {
        //ps
        try {
            String sql = "SELECT * FROM bookstore_db.tbl_book WHERE id = ?";
            ps = con.prepareStatement(sql);
            ps.setInt(1,id);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                Book foundBook = new Book(rs.getInt(1),
                                          rs.getString(2),
                                          rs.getString(3),
                                          rs.getDouble(4));
                return Optional.of(foundBook);
            }
        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return Optional.empty();
    }

    @Override
    public boolean deleteById(int id) {
        return false;
    }

    @Override
    public Book update(int id, double newPrice) {
        return null;
    }

    @Override
    public Book[] findAll() {
        return new Book[0];
    }

    @Override
    public List<Book> findAllBooks() {
        return List.of();
    }
}
