package in.org.rebit.bookstore.service;
import in.org.rebit.bookstore.entity.Book;
import in.org.rebit.bookstore.exception.BookNotFoundException;

import java.util.List;

//responsible for business methods
//responsible for dealing with business exceptions
public interface BookService {

    public boolean registerNewBook(Book bookToBeRegistered);
    //search All Books
    List<Book> searchAllBooks();

    //search Book By Id
    Book searchBookById(int id)throws BookNotFoundException;

    //update book Price
    Book updateBook(int id,double newPrice) throws BookNotFoundException;

    //delete the book
    boolean deleteBookById(int id) throws BookNotFoundException;
}
