package in.org.rebit.bookstore.dao.impl;

import in.org.rebit.bookstore.dao.BookDao;
import in.org.rebit.bookstore.entity.Book;
import jakarta.persistence.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public class BookJpaDaoImpl implements BookDao {

    @PersistenceContext
    private EntityManager em;

    @Transactional
    @Override
    public boolean save(Book bookToBeSaved) {
            em.persist(bookToBeSaved);  //insert record in DB
            return true;
       }

    @Override
    public Optional<Book> findById(int id) {
        Book foundBook = em.find(Book.class,id);
        return Optional.of(foundBook);
    }

    @Override
    public boolean deleteById(int id) {
        Book foundBook = em.find(Book.class,id);//select
        return foundBook != null;
    }

    @Override
    public Book update(int id, double newPrice) {
        return null;
    }

    @Override
    public Book[] findAll() {
        return new Book[0];
    }

    @Override
    public List<Book> findAllBooks() {
        //JPQL (HQL)
        String jpql = "FROM Book";
        TypedQuery<Book> query = em.createQuery(jpql,Book.class);
        List<Book> books = query.getResultList();
        return books;
    }
}
