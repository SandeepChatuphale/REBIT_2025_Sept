package in.org.rebit.infrabooking.rest.controller;

import in.org.rebit.infrabooking.entity.Room;
import in.org.rebit.infrabooking.exception.RoomNotFoundException;
import in.org.rebit.infrabooking.service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

//@Controller
@RestController
public class RoomRestController {

    @Autowired
    private RoomService service;

    //@ResponseBody
    @GetMapping("/rooms")
    public List<Room> searchAll(){
        return this.service.getAllRooms();
    }


    //@ResponseBody
    @GetMapping("/rooms/{id}")
    public Room searchById(@PathVariable int id) throws RoomNotFoundException {
        return this.service.getRoomById(id);
    }


}
