package in.org.rebit.infrabooking;

import in.org.rebit.infrabooking.entity.Room;
import in.org.rebit.infrabooking.exception.RoomNotFoundException;
import in.org.rebit.infrabooking.service.RoomService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.util.List;

@SpringBootApplication
public class RoomApplication {

    public static void main(String[] args) {

        ConfigurableApplicationContext factory = SpringApplication.run(RoomApplication.class);
        RoomService service = factory.getBean(RoomService.class);

        int choice = 4;

        switch (choice) {
            case 1:
                Room r1 = new Room();
                r1.setId(1);
                r1.setAvailable(true);
                r1.setCapacity(12);
                r1.setType("Meeting");
                service.registerRoom(r1);
                break;
            case 2:
                List<Room> rooms = service.getAllAvailableRooms(false);
                System.out.println(rooms);
                break;
            case 3:
                rooms = service.getRoomsByAvailablityAndCapacity(true,12);
                System.out.println(rooms);
                break;
            case 4:
                try {
                    service.removeRoomById(23);
                } catch (RoomNotFoundException e) {
                    throw new RuntimeException(e);
                }

        }
    }
}
