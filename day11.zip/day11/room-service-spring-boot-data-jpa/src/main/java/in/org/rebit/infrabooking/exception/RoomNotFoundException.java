package in.org.rebit.infrabooking.exception;

public class RoomNotFoundException extends Throwable {
    public RoomNotFoundException(int id) {
        super("Room with " + id +" NOT Found");
    }
}
