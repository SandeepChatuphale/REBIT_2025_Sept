package in.org.rebit.helloworld.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class HelloworldSpringBootApplication {

	public static void main(String[] args) {
		try(ConfigurableApplicationContext factory =
					SpringApplication.run(HelloworldSpringBootApplication.class))
		{

		}
	}

}
