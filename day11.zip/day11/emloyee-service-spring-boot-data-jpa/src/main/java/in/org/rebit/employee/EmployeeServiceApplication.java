package in.org.rebit.employee;


import in.org.rebit.employee.exception.EmployeeNotFoundException;

import in.org.rebit.employee.service.EmployeeService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class EmployeeServiceApplication {
    public static void main(String[] args) throws EmployeeNotFoundException {

        ConfigurableApplicationContext factory;
        factory = SpringApplication.run(EmployeeServiceApplication.class);

        EmployeeService service = factory.getBean(EmployeeService.class);
        int choice = -1;
        switch (choice){
            case 1:
                Employee e = new Employee();
                e.setEmail("sandeep@gmail.com");
                e.setPassword("sandeep");
                List<String> roles = new ArrayList<>();
                roles.add("ROLE_USER");
                roles.add("ROLE_ADMIN");
                e.setRoles(roles);
                service.registerEmployee(e);
                break;
            case 2:
                Employee ee = service.findByEmail("sandeep@gmail.com");
                System.out.println(ee.getRoles());
                break;
            case 3:
                service.deleteByEmail("sandeep@gmail.com");

        }
    }
}
