package in.org.rebit.employee.repository.impl;

import in.org.rebit.employee.Employee;
import in.org.rebit.employee.repository.EmployeeRepository;

import jakarta.persistence.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Repository
public class EmployeeRepositoryImpl implements EmployeeRepository {

    @PersistenceContext
    private EntityManager em;


    @Transactional
    @Override
    public Optional<Employee> findByEmail(String email) {

        Employee e = null;
            String jpql = "FROM Employee WHERE email = :e";
            TypedQuery<Employee> query = em.createQuery(jpql, Employee.class);
            query.setParameter("e", email);
            e = query.getSingleResult();
        return Optional.of(e);
    }

    @Transactional
    @Override
    public Employee save(Employee e) {
        em.persist(e); //insert
        return e;
    }

    @Transactional
    @Override
    public void deleteByEmail(String email) {
           String jpql = "DELETE FROM Employee WHERE email = :e";
           Query query = em.createQuery(jpql);
           query.setParameter("e", email);
           int i = query.executeUpdate();
           em.close();
    }

}
