package in.org.rebit.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HelloController {

    @ResponseBody
    @GetMapping("/welcome")
    public String greet(){
        System.out.println("In greet");
        return "Hello"; //data
    }
    @ResponseBody
    @GetMapping("/welcome/{name}")
    public String greetWithName(@PathVariable String name){
        System.out.println("In greet " + name);
        return "Hello " + name; //data
    }


}
