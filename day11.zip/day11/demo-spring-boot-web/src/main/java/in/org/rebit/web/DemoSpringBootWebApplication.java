package in.org.rebit.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.context.AnnotationConfigServletWebServerApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class DemoSpringBootWebApplication {


	public static void main(String[] args) {
		System.out.println("====in main");
		ConfigurableApplicationContext ctx = SpringApplication.run(DemoSpringBootWebApplication.class, args);
			
	}

}
