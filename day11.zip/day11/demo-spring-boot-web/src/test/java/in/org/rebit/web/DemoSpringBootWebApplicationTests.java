package in.org.rebit.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringBootWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
