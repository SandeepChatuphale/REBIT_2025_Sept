package in.org.rebit.employee.rest.controller;

import in.org.rebit.employee.entity.Employee;
import in.org.rebit.employee.exception.EmployeeNotFoundException;
import in.org.rebit.employee.service.EmployeeService;
import in.org.rebit.employee.service.impl.EmployeeServiceImpl;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;


@RestController
@RequestMapping("/employees")
public class EmployeeRestController {

    @Autowired
    private EmployeeService service;

    @ResponseStatus(code = HttpStatus.CREATED)
    @PostMapping()
    public Employee registerEmployee(@Valid @RequestBody Employee e){
        return this.service.registerEmployee(e);
    }

    @ResponseStatus(code = HttpStatus.OK)
    @GetMapping("/{email}")
    public Employee searchEmployeeByEmail(@PathVariable String email) throws EmployeeNotFoundException {
        return this.service.findByEmail(email);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ProblemDetail handleMethodArgumentNotValidException(MethodArgumentNotValidException e){

        return e.getBody();
    }


}
