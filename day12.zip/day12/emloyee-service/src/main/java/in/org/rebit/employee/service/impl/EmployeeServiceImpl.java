package in.org.rebit.employee.service.impl;

import in.org.rebit.employee.entity.Employee;
import in.org.rebit.employee.exception.EmployeeNotFoundException;
import in.org.rebit.employee.repository.EmployeeRepository;
import in.org.rebit.employee.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeRepository repo;

    //Constructor-injection
    @Autowired
    public EmployeeServiceImpl(EmployeeRepository repo){
        this.repo = repo;
    }
    @Override
    public Employee findByEmail(String email) throws EmployeeNotFoundException {
        Optional<Employee> o = this.repo.findByEmail(email);
        return o.orElseThrow(() -> new EmployeeNotFoundException());
    }
    @Override
    public Employee registerEmployee(Employee e) {
        return this.repo.save(e);
    }

    @Override
    public void deleteByEmail(String email) {
        this.repo.deleteByEmail(email);
    }

}
