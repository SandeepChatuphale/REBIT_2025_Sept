import in.org.rebit.bookstore.entity.Book;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class DemoDeleteById {
    public static void main(String[] args) {

        EntityManagerFactory factory ;
        factory = Persistence.createEntityManagerFactory("bookUnit");
        EntityManager em = factory.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        //DB operation
        Book foundBook = em.find(Book.class,1);//select
        em.remove(foundBook);   //delete query


        tx.commit();
        em.close();
        factory.close();
    }
}
