import in.org.rebit.bookstore.entity.Book;
import jakarta.persistence.*;

import java.util.List;

public class DemoFindAll {
    public static void main(String[] args) {
        EntityManagerFactory factory ;
        factory = Persistence.createEntityManagerFactory("bookUnit");
        EntityManager em = factory.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        //JPQL (HQL)
        String jpql = "FROM Book";
        TypedQuery<Book> query = em.createQuery(jpql,Book.class);
        List<Book> books = query.getResultList();


        tx.commit();
        em.close();
        factory.close();

    }
}
