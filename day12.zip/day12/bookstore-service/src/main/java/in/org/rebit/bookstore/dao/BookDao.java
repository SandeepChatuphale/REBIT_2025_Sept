package in.org.rebit.bookstore.dao;

import in.org.rebit.bookstore.entity.Book;
import in.org.rebit.bookstore.exception.BookNotFoundException;

import java.util.List;
import java.util.Optional;

public interface BookDao {

    boolean save(Book bookToBeSaved);
    Optional<Book> findById(int id);
    boolean deleteById(int id);
    Book update(int id,double newPrice);
    Book[] findAll();
    List<Book> findAllBooks();
}
