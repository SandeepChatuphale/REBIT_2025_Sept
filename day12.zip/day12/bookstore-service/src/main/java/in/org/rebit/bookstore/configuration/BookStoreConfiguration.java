package in.org.rebit.bookstore.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@EnableTransactionManagement //enable support for transaction
@Configuration
@ComponentScan("in.org.rebit.bookstore")
public class BookStoreConfiguration {
    @Bean
    LocalEntityManagerFactoryBean getFactoryBean(){
        LocalEntityManagerFactoryBean entityManagerFactory;
        entityManagerFactory = new LocalEntityManagerFactoryBean();
        entityManagerFactory.setPersistenceUnitName("bookUnit");
        return entityManagerFactory;
    }
    //this bean manages Transaction automatically
    @Bean
    JpaTransactionManager getTransactionManager(){
        JpaTransactionManager tx = new JpaTransactionManager();
        tx.setEntityManagerFactory(getFactoryBean().getObject());
        return tx;
    }
}
