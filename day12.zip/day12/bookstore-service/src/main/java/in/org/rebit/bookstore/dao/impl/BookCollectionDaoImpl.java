package in.org.rebit.bookstore.dao.impl;

import in.org.rebit.bookstore.dao.BookDao;
import in.org.rebit.bookstore.entity.Book;
import in.org.rebit.bookstore.exception.BookNotFoundException;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;


public class BookCollectionDaoImpl implements BookDao
{
    private List<Book> books;

    public BookCollectionDaoImpl(){
        this.books = new ArrayList<>();
    }

    public boolean save(Book bookToBeSaved)
    {
        this.books.add(bookToBeSaved);
        //send email
        return true;
    }

    public Optional<Book> findById(int id)  {
        for(Book foundBook : this.books)
        {
            if(foundBook !=null && foundBook.getId() == id)
                return Optional.of(foundBook);
        }
        return Optional.empty();
    }


    public Book update(int id,double newPrice) {
        Book bookToUpdate = findById(id).get();
        bookToUpdate.setPrice(newPrice);
        return bookToUpdate;
    }

    public boolean deleteById(int id){
        Iterator<Book> i = this.books.iterator();//I
        while (i.hasNext()){
            Book nextBook = i.next();
            if(nextBook.getId() == id) {
                i.remove();
                return true;
            }
        }
    return false;

    }

    public Book[] findAll(){
        return null;
    }

    public List<Book> findAllBooks()
    {
        return this.books;
    }

}
