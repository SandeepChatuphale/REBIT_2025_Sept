package in.org.rebit.bookstore.rest.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class BookRestController {


}
