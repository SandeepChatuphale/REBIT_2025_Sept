package in.org.rebit.bookstore.view;
public enum MessageType {

    SUCCESS,
    ERROR
}
