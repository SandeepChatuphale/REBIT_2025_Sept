import java.util.Optional;

public class DemoOptional {
    public static void main(String[] args) {
        Optional<String> o = Optional.of("data");
        if(o.isPresent()) {
            String value = o.get();
            System.out.println(value);
        }
        Optional eo = Optional.empty();
        System.out.println(eo.isPresent());
        System.out.println(eo.isEmpty());

        Optional<Void> ooo = Optional.of(null);
        System.out.println(ooo.get());
    }
}
