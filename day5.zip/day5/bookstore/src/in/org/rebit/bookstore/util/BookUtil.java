package in.org.rebit.bookstore.util;
import in.org.rebit.bookstore.entity.Book;

import java.util.*;
import java.util.stream.Collectors;

public class BookUtil {
    public static void sortBooksByPrice(List<Book> books){
        Collections.sort(books);
    }
    public static void sortBooksByTitle(List<Book> books){
        Collections.sort(books,new BookComparisonByTitle());
    }

    //generic method can sort books on any criteria
    //passed to it using lambda function
    public static void sortBooks(List<Book> books,Comparator<Book> c) {
        Collections.sort(books, c);
    }

}
