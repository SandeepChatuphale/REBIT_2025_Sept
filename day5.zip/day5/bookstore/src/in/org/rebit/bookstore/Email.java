package in.org.rebit.bookstore;

public class Email {

    public void sendEmail(){}
}
