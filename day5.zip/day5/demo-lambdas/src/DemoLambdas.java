import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

interface Taxable{
    double calculateTax(double income);
}
interface Joiner{
    String join(String a,String b);
}
public class DemoLambdas {
    public static void main(String[] args) {
        Joiner j;
        j = (String a, String b) -> {return "";};
        j = (a, b) -> {return "";};
        j = (String a,String b) -> "";
        j = (String a,String b) -> "";

        j = (a, b) -> "";

        int i = 10;
        I r = () -> System.out.println();
        Taxable t;
        t = (double income) -> {return 88;};
        t = (income) -> {return 88;};
        t = income -> {return 88;};
        t = income -> 88;

        System.out.println(t.calculateTax(23));

        Predicate<String> p;
        p = str -> str.startsWith("p");
        p.test("Pune");

        Function<String,Integer> f;
        f = (String str) -> {return 10;};
        f = (str) -> {return 10;};
        f = str -> 10;
        System.out.println(f.apply("mumbai"));
        Supplier<String> s;
        s = () -> "";
        Consumer<String> c;
        c = str -> System.out.println();









    }
}

@FunctionalInterface
interface I{
    void display();
}