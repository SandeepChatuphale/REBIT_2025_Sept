public class BookStoreApplication{
public static void main(String[] args)
{

	Book b1 ;
	b1 = new Book();
	b1.setId(1);
	//b1.display();
	System.out.println(b1.price);
}
}