public class Book{
	//instance variables
	private int id;
	private String title;
	private String author;
	private double price;

	public void setId(int i){
		id = i;
	}

	public int getId(){
		return id;
	}
	
	public void display(){
		System.out.println(id);
System.out.println(title);
System.out.println(author);
System.out.println(price);
	}
}