public class DemoIf {
    public static void main(String[] args) {
        int age = 20;

        if(age > 18){
            System.out.println("Eligible for voting");
        }

        if(age > 18)
        {
            System.out.println("Yes");
        }
        //System.out.println();
        else
            System.out.println("No");

        int num = 1;

        if(num == 1)
        {
            System.out.println("ONE");
        }
        //System.out.println();
        else if (num == 2) {
            System.out.println("Two");
        }
        else if (num == 3) {
            System.out.println("THREE");
        }
        else
        {
            System.out.println("INvalid choice");
        }

    }
}
