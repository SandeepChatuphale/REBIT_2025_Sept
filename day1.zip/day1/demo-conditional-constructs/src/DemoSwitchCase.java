public class DemoSwitchCase {
    public static void main(String[] args) {

        int num = 1;

        //old traditional syntax
        switch (num)
        {
            case 1:
                System.out.println("ONE");
                break;
            case 2:
                System.out.println("Two");
                break;
            case 3:
                System.out.println("THREE");
                break;
        }
    }
}
