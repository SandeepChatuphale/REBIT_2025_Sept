class DemoMethod{

public static void main(String[] args)
{
	print();//call
	printName("abc");
}

//instance method
//access_specifier(optional) return_type name(arguments if //any){}



//static method
//static access_specifier(optional) return_type name(arguments if //any){}


static void print(){
	System.out.println("In print()");
}

int calculateSalary(){
	return 78;
}

static public void printName(String name){
}
}