class DemoPrimitiveDataType{
public static void main(String[] args)
{
	//data_type name_of_variable;
	/*byte
	short	
	int
	long

	float
	double

	char
	boolean */
	
	int age = 78;
	System.out.println(age);

	//age = 78.8;//ERROR

	//age = true;

	boolean status = false;

	//local variable
	float marks;
	
	//System.out.println(marks);//ERROR

	int empId;	
	int rollNumber;

	

}
}