public enum MessageType {

    SUCCESS,
    ERROR
}
