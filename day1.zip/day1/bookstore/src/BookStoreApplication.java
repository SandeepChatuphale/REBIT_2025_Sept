import java.util.Scanner;

public class BookStoreApplication {
    public static void main(String[] args) {
        Book b1 ;
        b1 = new Book(1,"Java","Kathy",89);


       Book b2 = new Book(1,"Spring","Kathy",89);
        System.out.println(b1.getId());
        System.out.println(b1.getAuthor());
        System.out.println(b1.getPrice());
        System.out.println(b1.getTitle());




        BookView view = new BookView();
        Scanner sc = new Scanner(System.in);

        int choice = 0;
        do {
            view.showMenu();
            System.out.println("Enter your choice");
            choice = sc.nextInt();
            switch (choice) {
                case 1:
                    view.printMessage("Adding new book");
                    break;
                case 2:
                    view.printMessage("Showing all books");
                    break;
                case -1:
                    view.printMessage("Thank you visit again");
                    break;
                default:
                    view.printMessage("Invalid choice try again",MessageType.ERROR);
            }}while (choice != -1);




    }
}
