public class BookView {

    public void showMenu()
    {

        // String menu ="1. Add Book \n"+
        //        "2. Show All  \n"+
        //       "-1. Exit";

        //text block
        String menu = """
                    1. Add Book
                    2. Show All books
                    -1. Exit
                """;

        System.out.println(menu);
    }

    //method overloading
    public void printMessage(String message){
        System.out.println(message);
    }
    public void printMessage(String message,MessageType messageType){
        if(messageType == MessageType.SUCCESS)
            printMessage(message);
        else
            System.err.println(message);
    }
}