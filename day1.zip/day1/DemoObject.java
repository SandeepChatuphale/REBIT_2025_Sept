class DemoObject{

public static void main(String[] args)
{
	//className referenceName = new className();
	DemoObject d = new DemoObject();

	//dot operator
	//membership operator
	d.accept(12);
}

void accept(int data){
}

}