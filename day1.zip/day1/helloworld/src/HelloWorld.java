public class HelloWorld
{
    private int id;

    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
