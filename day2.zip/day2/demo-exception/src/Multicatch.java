public class Multicatch {
    public static void main(String[] args) {

        try
        {

        }
        catch (ArithmeticException | NullPointerException e)
        {

        }
    }
}
