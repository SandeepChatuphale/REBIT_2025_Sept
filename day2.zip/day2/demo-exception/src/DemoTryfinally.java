public class DemoTryfinally {
    public static void main(String[] args) {

        try
        {

        }
        finally{}

    }
}
