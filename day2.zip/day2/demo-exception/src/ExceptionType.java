import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.SQLException;

public class ExceptionType {
    public static void main(String[] args)throws FileNotFoundException, SQLException {
        daoCode();
    }

    static void daoCode()throws FileNotFoundException{
        FileInputStream fis = new FileInputStream("");
    }
}
