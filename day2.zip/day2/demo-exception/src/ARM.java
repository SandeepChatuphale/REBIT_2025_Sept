import java.io.FileInputStream;
import java.io.IOException;

public class ARM {
    public static void main(String[] args) {
        FileInputStream fis = null;
        try {
            fis = new FileInputStream("");
        }
        catch (Exception e)
        {}
        finally {
            //closing resource can lead to exception
            //hence handle it otheriwse program terminated abruptly
            try {
                fis.close();
            }
            catch (IOException e){}
        }
        //try with resources OR ARM
        try(FileInputStream fis1 = new FileInputStream(""))
        {
        }
        catch (Exception e){}
    }
}
