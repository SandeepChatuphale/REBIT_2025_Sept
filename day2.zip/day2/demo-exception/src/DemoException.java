public class DemoException {
    public static void main(String[] args) {

        try {
            int result = 10 / 0;
            String str = null;
            System.out.println(args[0]);
            System.out.println(str.length());

            System.out.println("After");
            System.out.println(result);
        }
        //System.out.println("in between");//ERROR
        catch (ArithmeticException e){
           // System.out.println("Cannot divide by zero");
            e.printStackTrace();
        }
        catch (NullPointerException e){}
        catch (ArrayIndexOutOfBoundsException e){
            return;
        }
        catch (Exception e){}//Generic Exception
        finally {
            System.out.println("closing resources - always executes");
        }
        System.out.println("Done");
    }

}
