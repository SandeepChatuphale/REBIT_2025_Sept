
//responsible for accessing data-store
//typically 4 operations are carried out
//save - Create - C
//select - READ - R
//Update - UPDATE - U
//Delete - DELETE - D
//CRUD - operations
public class BookArrayDao {

    private Book[] books;
    private int index;

    public BookArrayDao(){
        this.books = new Book[2];
    }

    public BookArrayDao(int size){
        this.books = new Book[size];
    }

    public boolean save(Book bookToBeSaved)
    {
        this.books[index] = bookToBeSaved;
        index++;
        return true;
    }
    public boolean deleteById(int id){
        int searchIndex = 0;
        for(Book b : books)
        {
            if(b.getId() == id)
            {
                books[searchIndex] = null;
                return  true;
            }
            searchIndex++;
        }
        return  false;
    }
    public Book findById(int id)throws BookNotFoundException
    {
        for(Book foundBook : books)
        {
            if(foundBook.getId() == id)
                return foundBook;
        }
        //generate BookNotFoundException
        BookNotFoundException e = new BookNotFoundException();
        throw e;
    }

    public Book update(int id,double newPrice)
    {
        Book foundBook = findById(id);
        foundBook.setPrice(newPrice);
        return foundBook;
    }

    public Book[] findAll(){
        return this.books;
    }



}
