public class DemoArray {
    public static void main(String[] args) {

        //declaration
        Book[] books;

        //object creation OR instantiation
        books = new Book[2];

        //initialization
        books[0] = new Book("Java","Kathy",88);
        books[1] = new Book("Spring","Craig Walls",99);

        //basic-for-loop
        for(int i = 0;i<books.length;i++)
            System.out.println(books[i].getTitle());

        //enhanced for loop
        //added in JDK 5
        for(Book b : books)
            System.out.println(b.getTitle());

    }
}
