import java.util.InputMismatchException;
import java.util.Scanner;

public class BookStoreApplication {
    public static void main(String[] args) {
        Book b1 = null;
        BookView view = new BookView();
        BookArrayDao dao = new BookArrayDao();

        Scanner sc = new Scanner(System.in);
        try {

            view.printMessage("number of books registered are " + Book.getCount());


            int choice = 0;
            do {
                try {
                    view.showMenu();
                    choice = sc.nextInt();
                    switch (choice) {
                        case 1:
                            view.printMessage("Adding new book");
                            b1 = new Book("Java", "Kathy", 89);
                            boolean isSaved = dao.save(b1);
                            if (isSaved)
                                view.printMessage("Book Saved");
                            else
                                view.printMessage("Error try again", MessageType.ERROR);
                            break;
                        case 2:
                            view.printMessage("Showing all books");
                            view.printBook(b1);
                            break;
                        case 3:
                            boolean isDeleted = dao.deleteById(1);
                            if (isDeleted)
                                view.printMessage("Book Deleted");
                            else
                                view.printMessage("Some issue try again", MessageType.ERROR);
                            break;
                        case 4:
                            int id = 1;
                            try {
                                Book foundBook = dao.findById(id);
                                view.printBook(foundBook);
                            } catch (BookNotFoundException e) {
                                view.printMessage("Sorry Book with id " + id + " not found", MessageType.ERROR);

                            }
                            break;
                        case 5:
                            Book updatedBook = dao.update(1, 78);
                            if (updatedBook != null) {
                                view.printMessage("Book Price updated");
                            } else
                                view.printMessage("Price NOT Updated", MessageType.ERROR);

                            break;

                        case -1:
                            view.printMessage("Thank you visit again");
                            break;
                        default:
                            view.printMessage("Invalid choice try again", MessageType.ERROR);
                    }
                } catch (InputMismatchException e) {
                    view.printMessage("Please Enter int value ONLY", MessageType.ERROR);
                    sc.next(); //removing wrong i/P from buffer
                }
            } while (choice != -1);
        }
        finally {
            sc.close();
        }
    }
}