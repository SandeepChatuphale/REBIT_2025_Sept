//sub-class
public class BookNotFoundException extends Exception{}