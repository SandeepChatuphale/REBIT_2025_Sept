import java.util.List;
import java.util.Vector;

public class DemoVector {
    public static void main(String[] args) {
        List<String> cities = new Vector<>();
    }
}
