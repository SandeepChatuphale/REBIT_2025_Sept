import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class DemoArrayList {
    public static void main(String[] args) {
        List li = new ArrayList();
        System.out.println(li.isEmpty());
        System.out.println(li.size());
        li.add("Mumbai");
        li.add("Pune");
        System.out.println(li.size());
        li.add(45);
        System.out.println(li);
        System.out.println(li.size());
        System.out.println(li.isEmpty());
        li.set(1,"Poona");
        System.out.println(li);
        li.add(1,"Delhi");
        System.out.println(li);
        System.out.println(li.get(2));
        System.out.println(li.contains("Delhi"));

        //retrieve an element it index 2
        //String str = (String) li.get(3);



        li.clear();
        System.out.println(li);

        System.out.println(li.contains("Delhi"));


        //generics
        List<String> cities = new ArrayList<>();
        cities.add("Mumbai");
        //cities.add(23); //ERROR
        cities.add("Pune");
        cities.add("Delhi");

        System.out.println(cities);

        Collections.sort(cities);



        System.out.println(cities);
    }
}
