import java.util.HashMap;
import java.util.Map;

public class DemoHashMap {
    public static void main(String[] args) {
        Map<String,Integer> m = new HashMap<>();
        System.out.println(m.size());
        System.out.println(m.isEmpty());
        m.put("mumbai",22);
        m.put("pune",20);
        System.out.println(m);
        System.out.println(m.size());
        System.out.println(m.isEmpty());
        m.put("mumbai",11);
        m.put("delhi",11);
        System.out.println(m);
        System.out.println(m.get("mumbai"));
        System.out.println(m.containsKey("pune"));
        System.out.println(m.containsValue(11));
        m.clear();
        System.out.println(m);
        m.remove("pune");
    }
}
