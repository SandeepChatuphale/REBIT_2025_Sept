import in.org.rebit.bookstore.entity.Book;

import java.util.HashSet;
import java.util.Set;

public class Demo {
    public static void main(String[] args) {

        Set<String> cities = new HashSet<>();
        cities.add("pune");
        cities.add("pune");
        System.out.println(cities.size());

        System.out.println(cities);

        Set<Book> books = new HashSet<>();
        Book b1 = new Book("Java","Kathy",90);
        Book b2 = new Book("Java","Kathy",90);

        books.add(b1);
        books.add(b2);
        System.out.println(books.size());
        System.out.println(books);
    }
}
