package in.org.rebit.bookstore.exception;
//sub-class
public class BookNotFoundException extends Exception{
    public BookNotFoundException(String message) {
        super(message);//invoking super class constructor
    }
}