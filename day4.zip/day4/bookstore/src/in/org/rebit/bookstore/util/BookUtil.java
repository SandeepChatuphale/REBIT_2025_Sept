package in.org.rebit.bookstore.util;
import in.org.rebit.bookstore.entity.Book;

import java.util.*;
import java.util.stream.Collectors;

public class BookUtil {
    public static void sortBooksByPrice(List<Book> books){
        Collections.sort(books);
    }
    public static void sortBooksByTitle(List<Book> books){
        Collections.sort(books,new BookComparisonByTitle());
    }

    public static Map<Boolean,List<Book>> groupBy(List<Book> books)
    {
        Map<Boolean, List<Book>>
        mm = books.stream().collect(Collectors.partitioningBy(p -> p.getPrice()>50));

        Map<String,List<Book>> group = new HashMap<>();

        List<Book> cheap = new ArrayList<>();
        List<Book> costly = new ArrayList<>();

        for (Book b : books)
        {
            if(b.getPrice() < 50){
                cheap.add(b);
            }
            else {
                costly.add(b);
            }
        }

        group.put("cheap",cheap);
        group.put("costly",costly);

        return mm;
    }

}
