package in.org.rebit.bookstore.factory;

import in.org.rebit.bookstore.dao.BookDao;
import in.org.rebit.bookstore.dao.impl.BookCollectionDaoImpl;

public class BeanFactory {

    public BookDao getBookDao(){
        BookCollectionDaoImpl dao = new BookCollectionDaoImpl();
        return dao;
    }
}
