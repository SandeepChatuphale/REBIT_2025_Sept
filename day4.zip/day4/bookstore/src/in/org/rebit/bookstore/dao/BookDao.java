package in.org.rebit.bookstore.dao;

import in.org.rebit.bookstore.entity.Book;
import in.org.rebit.bookstore.exception.BookNotFoundException;

import java.util.List;

public interface BookDao {

    boolean save(Book bookToBeSaved);
    Book findById(int id)throws BookNotFoundException;
    boolean deleteById(int id)throws BookNotFoundException;
    Book update(int id,double newPrice)throws BookNotFoundException;
    Book[] findAll();
    List<Book> findAllBooks();
}
