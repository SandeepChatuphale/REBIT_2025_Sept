package in.org.rebit.bookstore.dao.impl;

import in.org.rebit.bookstore.dao.BookDao;
import in.org.rebit.bookstore.entity.Book;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.TransactionRequiredException;
import jakarta.persistence.EntityExistsException;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class BookJpaDaoImpl implements BookDao {
    private EntityManagerFactory factory;
    public BookJpaDaoImpl(){
        factory = Persistence.createEntityManagerFactory("bookUnit");
    }
    @Override
    public boolean save(Book bookToBeSaved) {
        EntityManager em = factory.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        //DB operation
        try {
            em.persist(bookToBeSaved);  //insert record in DB
            return true;
        }
        catch (EntityExistsException e){
            e.printStackTrace();
        }
        catch (IllegalArgumentException e){
            e.printStackTrace();
        }
        catch (TransactionRequiredException e){
            e.printStackTrace();
        }
        tx.commit();
        em.close();
        return false;
    }

    @Override
    public Optional<Book> findById(int id) {
        EntityManager em = factory.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        Book foundBook = em.find(Book.class,id);
        tx.commit();
        em.close();
        if(foundBook == null)
            return Optional.empty();

        return Optional.of(foundBook);
    }

    @Override
    public boolean deleteById(int id) {
        EntityManager em = factory.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        Book foundBook = em.find(Book.class,id);//select
        if(foundBook!=null)
            em.remove(foundBook);   //delete query
        tx.commit();
        em.close();
        return foundBook != null;
    }

    @Override
    public Book update(int id, double newPrice) {
        return null;
    }

    @Override
    public Book[] findAll() {
        return new Book[0];
    }

    @Override
    public List<Book> findAllBooks() {
        EntityManager em = factory.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        //JPQL (HQL)
        String jpql = "FROM Book";
        TypedQuery<Book> query = em.createQuery(jpql,Book.class);
        List<Book> books = query.getResultList();

        String s = "SELECT DISTINCT title FROM Book";
        TypedQuery<String> q = em.createQuery(s,String.class);
        System.out.println(q.getResultList());

        tx.commit();
        em.close();
        return books;
    }

    public void close() {
        this.factory.close();
    }
}
