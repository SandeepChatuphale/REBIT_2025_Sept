package in.org.rebit.employee;

import in.org.rebit.employee.configuration.EmployeeApplicationConfiguration;
import in.org.rebit.employee.exception.EmployeeNotFoundException;

import in.org.rebit.employee.repository.EmployeeRepository;
import in.org.rebit.employee.repository.impl.EmployeeRepositoryImpl;
import in.org.rebit.employee.service.EmployeeService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.ArrayList;
import java.util.List;

public class EmployeeServiceApplication {
    public static void main(String[] args) throws EmployeeNotFoundException {

        AnnotationConfigApplicationContext factory;
        factory = new AnnotationConfigApplicationContext(EmployeeApplicationConfiguration.class);
        EmployeeService service = factory.getBean(EmployeeService.class);
        int choice = 3;
        switch (choice){
            case 1:
                Employee e = new Employee();
                e.setEmail("sandeep@gmail.com");
                e.setPassword("sandeep");
                List<String> roles = new ArrayList<>();
                roles.add("ROLE_USER");
                roles.add("ROLE_ADMIN");
                e.setRoles(roles);
                service.registerEmployee(e);
                break;
            case 2:
                Employee ee = service.findByEmail("sandeep@gmail.com");
                System.out.println(ee.getRoles());
                break;
            case 3:
                service.deleteByEmail("sandeep@gmail.com");

        }
    }
}
