package in.org.rebit.employee.repository.impl;

import in.org.rebit.employee.Employee;
import in.org.rebit.employee.repository.EmployeeRepository;
import jakarta.persistence.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public class EmployeeRepositoryImpl implements EmployeeRepository {

    private EntityManagerFactory factory;

    public EmployeeRepositoryImpl(){
        factory = Persistence.createEntityManagerFactory("employeeUnit");
    }

    @Override
    public Optional<Employee> findByEmail(String email) {

        Employee e = null;
        EntityManager em = factory.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
            String jpql = "FROM Employee WHERE email = :e";
            TypedQuery<Employee> query = em.createQuery(jpql, Employee.class);
            query.setParameter("e", email);
            e = query.getSingleResult();
            tx.commit();
            em.close();

        return Optional.of(e);
    }

    @Override
    public Employee save(Employee e) {
        EntityManager em = factory.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        em.persist(e); //insert
        tx.commit();
        em.close();
        return e;
    }

    @Override
    public void deleteByEmail(String email) {
          EntityManager em = factory.createEntityManager();
           EntityTransaction tx = em.getTransaction();
           tx.begin();
           String jpql = "DELETE FROM Employee WHERE email = :e";
           Query query = em.createQuery(jpql);
           query.setParameter("e", email);
           int i = query.executeUpdate();
           System.out.println(i);
           tx.commit();
           em.close();

    }


}
