function login(){

    const emailId = document.getElementById('email').value;
    const password = document.getElementById('password').value;


}