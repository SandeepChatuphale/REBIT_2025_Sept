function sayHello(){
    console.log('in sayHello');
    return "Hello";
}

sayHello();