
var age = 12;

//ES-6
let capacity = 12;
capacity = "ok";



const PI = 3.14;
