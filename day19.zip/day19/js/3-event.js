
function deleteRoom(){
    const result = confirm('are you sure?');
    console.log(result)
    if(result)
    {
            //delete Room
    }
    else{
        //cancelled
    }
}


function validate(){
    const emailValue =  document.getElementById('email').value
   // console.log(emailValue)
    if(emailValue=='' || emailValue==null){
        document.getElementById('error').innerHTML="Email is MUST"
    }
}


