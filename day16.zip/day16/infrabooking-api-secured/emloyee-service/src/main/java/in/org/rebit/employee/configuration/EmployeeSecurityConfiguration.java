package in.org.rebit.employee.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class EmployeeSecurityConfiguration  {

    @Autowired
    private UserDetailsService detailsService;

    @Bean
    SecurityFilterChain defaultSecurityFilterChain(HttpSecurity http) throws Exception {


        //disable csrf
        http.csrf( c -> c.disable() );

        //instructing spring to fetch UserDetails from given object
        http.userDetailsService(detailsService);

        //instructing spring security to authenticate every request
        http.authorizeHttpRequests(req -> req.anyRequest()
                                                                        .authenticated());
        //use http basic authentication type
        http.httpBasic(Customizer.withDefaults());
        return http.build();
    }
}
