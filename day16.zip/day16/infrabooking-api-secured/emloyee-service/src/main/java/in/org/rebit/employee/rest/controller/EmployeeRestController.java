package in.org.rebit.employee.rest.controller;

import in.org.rebit.employee.Employee;
import in.org.rebit.employee.exception.EmployeeNotFoundException;
import in.org.rebit.employee.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/employee")
public class EmployeeRestController {

    @Autowired
    private EmployeeService service;

    @GetMapping("/{email}")
    public Employee searchByEmail(@PathVariable String email) throws EmployeeNotFoundException {
        return this.service.findByEmail(email);
    }

    @PostMapping
    public Employee register(@RequestBody Employee e ){
        return this.service.registerEmployee(e);
    }

}
