package org.rebit.email.repository;

public interface EmailRepository {


}
