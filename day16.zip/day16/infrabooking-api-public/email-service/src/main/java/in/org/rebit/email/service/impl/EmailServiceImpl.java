package org.rebit.email.service.impl;

import in.org.rebit.email.entity.Email;
import org.rebit.email.repository.EmailRepository;
import org.rebit.email.service.EmailService;

public class EmailServiceImpl implements EmailService {
    private EmailRepository repo;
    @Override
    public Email saveEmail(Email e) {
        return null;
    }
}
