package in.org.rebit.email.rest.controller;

import in.org.rebit.email.dto.RoomDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/email")
public class EmailRestController {

    @Autowired
    private org.rebit.email.service.EmailService service;

    @PostMapping
    public boolean sendEmail(@RequestBody RoomDto r){
        System.out.println("email sent");
        System.out.println(r.getId());
        System.out.println(r.getType());
        System.out.println(r.getCapacity());

        //loggedin employee email
        System.out.println("sandeep@gmail.com");
        return true;
    }
}
