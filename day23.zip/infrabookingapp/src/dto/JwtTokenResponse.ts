
export class JwtTokenResponse{
    constructor(public jwtToken:string){}
}