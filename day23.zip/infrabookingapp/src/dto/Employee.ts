export class Employee{
    constructor(public email:string='',public password:string='',
        public roles : string[] = []){}
}