import { Injectable } from '@angular/core';
import { Employee } from '../../dto/Employee';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { JwtTokenResponse } from '../../dto/JwtTokenResponse';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  public readonly authenticated_key : string  = 'authenticated_key';

  private authenticated : boolean = false;
  private employees : Employee[] = [];
  public authentication  = new Employee();

  
  registerEmployee(e : Employee){
   // this.employees.push(e);
  }

  constructor(private http:HttpClient) { 
    /*this.authenticated =  JSON.parse(
      sessionStorage.getItem(this.authenticated_key)+'');

      if(this.authenticated){
        this.authentication.email = sessionStorage.getItem('username')+'';
      }*/
}
  login(e : Employee) : Observable<JwtTokenResponse> {
    
    return this.http.
post<JwtTokenResponse>('http://localhost/employee-service/employee/login',e)

     /*         
    for(let foundEmployee of this.employees){
      if(foundEmployee.email == e.email && foundEmployee.password == e.password)
        
        //to keep session alive even after refresh
        sessionStorage.setItem(this.authenticated_key,true+'');
        sessionStorage.setItem('username',this.authentication.email);

        return true;
    }
    return false; */
  }

  private getRoles():string[]{
    //get token
    const token : string = this.getToken()+'';

    //get roles from token
    //a.b.c
    let payload = token.split('.')[1]
    console.log("payload  ===> " + payload)
    let decodedPayloaded : any  = atob(payload);
    console.log("decodedPayloaded===>" +decodedPayloaded)
    let parsedPayload = JSON.parse(decodedPayloaded);
    console.log(parsedPayload.ROLES_CLAIM)
    
    return [];
  }

  findProfileByEmail(email:string){
    this.getRoles();
    
    this.authenticated = true;
    this.authentication.email = email;
    this.authentication.roles = []
    this.authentication.password = ''

    /*
      let h = new HttpHeaders();
      h = h.append("Authorization","Bearer " + token);

      this.http.get('http://localhost/employee-service/employee/'+email,
        {headers:h}).subscribe(
        res => console.log(res)
      )*/
  }

  isAuthenticated() : boolean{
    return this.authenticated;
  }

  invalidateSession():boolean{
    this.authenticated = false;
    sessionStorage.clear();
    this.authentication = new Employee();
    return this.authenticated;
  }

  saveToken(token:string):void{
    sessionStorage.setItem(this.authenticated_key,token)
  }

  getToken():string{
    return sessionStorage.getItem(this.authenticated_key)+''
  }
}
