import in.org.rebit.bookstore.entity.Book;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;


public class DemoSave {
    public static void main(String[] args) {

       
        EntityManagerFactory factory ;
        factory = Persistence.createEntityManagerFactory("bookUnit");

        System.out.println(factory.getClass());
        Book b = new Book(1,"a","a",10);

        EntityManager em;
        em = factory.createEntityManager();
        System.out.println(em.getClass());

        EntityTransaction tx ;
        tx = em.getTransaction();
        tx.begin();
        //DB operation
      
        tx.commit();
        em.close();
        factory.close();





    }
}
