package in.org.rebit.bookstore.factory;

import in.org.rebit.bookstore.dao.BookDao;
import in.org.rebit.bookstore.dao.impl.BookJdbcDaoImpl;
import in.org.rebit.bookstore.service.BookService;
import in.org.rebit.bookstore.service.impl.BookServiceImpl;

public class BeanFactory implements AutoCloseable {
    private BookJdbcDaoImpl dao;
    private BookServiceImpl service;

    public BeanFactory(){
        this.dao = new BookJdbcDaoImpl();
        this.service = new BookServiceImpl(this.dao);
    }
    public BookDao getBookDao(){
        return dao;
    }
    public BookService getBookService() {
        return service;
    }
    @Override
    public void close(){
        this.dao.close();
    }

}
