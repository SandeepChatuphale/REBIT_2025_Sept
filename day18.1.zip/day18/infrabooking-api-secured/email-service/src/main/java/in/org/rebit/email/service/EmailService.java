package org.rebit.email.service;

public interface EmailService {

    in.org.rebit.email.entity.Email saveEmail(in.org.rebit.email.entity.Email e);
}
