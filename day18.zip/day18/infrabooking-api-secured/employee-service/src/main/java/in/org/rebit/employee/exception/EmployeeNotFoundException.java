package in.org.rebit.employee.exception;

public class EmployeeNotFoundException extends Exception {
}
