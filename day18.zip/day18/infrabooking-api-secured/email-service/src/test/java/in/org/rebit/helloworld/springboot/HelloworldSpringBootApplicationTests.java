package in.org.rebit.helloworld.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloworldSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
