package in.org.rebit.bookstore.service.impl;

import in.org.rebit.bookstore.dao.BookDao;
import in.org.rebit.bookstore.dao.impl.BookCollectionDaoImpl;
import in.org.rebit.bookstore.entity.Book;
import in.org.rebit.bookstore.exception.BookNotFoundException;
import in.org.rebit.bookstore.service.BookService;

import java.util.List;
import java.util.Optional;

public class BookServiceImpl implements BookService {
    //coding to interface
    private BookDao dao;

    //constructor injection
    public BookServiceImpl(BookDao dao){
        this.dao = dao;
    }

    //setter injection
    public void setDao(BookDao dao) {
        this.dao = dao;
    }

    @Override
    public boolean registerNewBook(Book bookToBeRegistered) {
        return this.dao.save(bookToBeRegistered);
    }

    @Override
    public List<Book> searchAllBooks() {
        return this.dao.findAllBooks();
    }

    @Override
    public Book searchBookById(int id) throws BookNotFoundException {

        Optional<Book> o = this.dao.findById(id);
        return o.orElseThrow(() -> new BookNotFoundException("Book with id " + id +" NOT Found"));

        /*if(o.isPresent()) {
            Book foundBook = o.get();
            return foundBook;
        }
        else
            throw new BookNotFoundException("Book with id " + id +" NOT Found");*/
    }

    @Override
    public Book updateBook(int id,double newPrice) throws BookNotFoundException {
        Book bookToBeUpdated = searchBookById(id);
        bookToBeUpdated.setPrice(newPrice);
        return bookToBeUpdated;
    }

    @Override
    public boolean deleteBookById(int id) throws BookNotFoundException {
        return this.dao.deleteById(id);
    }
}
