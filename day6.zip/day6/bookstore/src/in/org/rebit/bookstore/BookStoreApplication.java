package in.org.rebit.bookstore;

import in.org.rebit.bookstore.entity.Book;
import in.org.rebit.bookstore.exception.BookNotFoundException;
import in.org.rebit.bookstore.factory.BeanFactory;
import in.org.rebit.bookstore.service.BookService;
import in.org.rebit.bookstore.service.impl.BookServiceImpl;
import in.org.rebit.bookstore.util.BookUtil;
import in.org.rebit.bookstore.view.BookView;
import in.org.rebit.bookstore.view.MessageType;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class BookStoreApplication {
    public static void main(String[] args) {
        BookView view = new BookView();
        BeanFactory factory = new BeanFactory();
        BookService service = factory.getBookService();
        Scanner sc = new Scanner(System.in);
        try {
            view.printMessage("number of books registered are " + Book.getCount());

            int choice = 0;
            do {
                try {
                    view.showMenu();
                    choice = sc.nextInt();
                    switch (choice) {
                        case 1:
                            view.printMessage("Adding new book");
                            view.printMessage("Enter Title");
                            String title = sc.next();
                            view.printMessage("Enter Author");
                            String author = sc.next();
                            view.printMessage("Enter Price");
                            double price = sc.nextDouble();
                            Book b1 = new Book(title, author, price);
                           // boolean isSaved = dao.save(b1);
                            boolean isSaved = service.registerNewBook(b1);
                            if (isSaved)
                                view.printMessage("Book Saved");
                            else
                                view.printMessage("Error try again", MessageType.ERROR);
                            break;
                        case 2:
                           // List<Book> books = dao.findAllBooks();
                            List<Book> books = service.searchAllBooks();
                            view.printBooks(books);
                            break;
                        case 3:
                            try {
                                boolean isDeleted = service.deleteBookById(1);
                                view.printMessage("Book Deleted");
                            }
                            catch (BookNotFoundException e){
                                view.printMessage("Some issue try again", MessageType.ERROR);
                            }
                           
                            break;
                        case 4:
                            int id = 1;
                            try {
                               // Book foundBook = dao.findById(id);
                                Book foundBook = service.searchBookById(id);
                                view.printBook(foundBook);
                            } catch (BookNotFoundException e) {
                                view.printMessage("Sorry Book with id " + id + " not found", MessageType.ERROR);
                                e.printStackTrace();
                            }
                            break;
                        case 5:
                            try {
                                Book updatedBook = service.updateBook(1, 78);
                                view.printMessage("Book Price updated");
                            } catch (BookNotFoundException e) {
                                view.printMessage("Price NOT Updated", MessageType.ERROR);
                                e.printStackTrace();//TODO log to log file
                            }
                            break;
                        case 6:
                            List<Book> allBooks = service.searchAllBooks();
                            BookUtil.sortBooksByPrice(allBooks);
                            view.printBooks(allBooks);
                            break;
                        case 7:
                            allBooks = service.searchAllBooks();
                            BookUtil.sortBooks(allBooks,(bb1,b2) -> bb1.getTitle().compareTo(b2.getTitle()));
                            view.printBooks(allBooks);
                            break;
                        case 8:
                            allBooks = service.searchAllBooks();
                            BookUtil.sortBooks(allBooks,(bb1,b2) -> bb1.getAuthor().compareTo(b2.getAuthor()));
                            view.printBooks(allBooks);
                            break;
                        case 9:
                            BookUtil.groupBy(service.searchAllBooks());
                            break;
                        case 10:
                             List<Book> searchedBooks = BookUtil.searchBooksByCriteria(service.searchAllBooks(),
                                                     b -> b.getAuthor().startsWith("A"));
                             view.printBooks(searchedBooks);
                            break;
                        case 11:
                            BookUtil.searchBooksByCriteria(service.searchAllBooks(),
                                    b -> b.getPrice()<50);

                            break;
                        case 12:

                            long count = BookUtil.countOfBooksByCriteria(service.searchAllBooks(),
                                    b -> b.getAuthor().equals("Kathy")
                                    );
                            view.printMessage("Kathy has written " + count +"  books");
                        case -1:
                            view.printMessage("Thank you visit again");
                            break;
                        default:
                            view.printMessage("Invalid choice try again", MessageType.ERROR);
                    }
                } catch (InputMismatchException e) {
                    view.printMessage("Please Enter int value ONLY", MessageType.ERROR);
                    sc.next(); //removing wrong i/P from buffer
                }
            } while (choice != -1);
        }
        finally {
            sc.close();
        }
    }
}