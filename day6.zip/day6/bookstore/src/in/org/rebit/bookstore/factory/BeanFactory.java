package in.org.rebit.bookstore.factory;

import in.org.rebit.bookstore.dao.BookDao;
import in.org.rebit.bookstore.dao.impl.BookCollectionDaoImpl;
import in.org.rebit.bookstore.service.BookService;
import in.org.rebit.bookstore.service.impl.BookServiceImpl;

public class BeanFactory {

    public BookDao getBookDao(){
        BookCollectionDaoImpl dao = new BookCollectionDaoImpl();
        return dao;
    }

    public BookService getBookService()
    {
        BookServiceImpl service = new BookServiceImpl(getBookDao());
        //service.setDao(getBookDao());//DI
        return service;
    }

}
