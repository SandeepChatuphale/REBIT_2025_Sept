import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class StreamDemo {
    public static void main(String[] args) {

        List<String> cities = new ArrayList<>();
        cities.add("Pune");
        cities.add("Patna");
        cities.add("Mumbai");
        cities.add("Manglore");
        cities.add("Delhi");

        List<String> citiesP = new ArrayList<>();
        for(String c : cities){
            if(c.startsWith("P"))
                citiesP.add(c);
        }
        System.out.println(citiesP);
        //from jdk 8 and above
        //step 1
        Stream<String> stream = cities.stream();
        //step 2 - intermediate operation
        Stream<String> filteredStream = stream.filter(c -> c.startsWith("P"));
        //step 3 - terminal operation
        List<String> cp = filteredStream.toList();



        List<String> result = cities.stream()
                                    .filter(c -> c.startsWith("P"))
                                    .toList();


        result.forEach(s -> System.out.println(s));





        List<String> citiesLength = new ArrayList<>();
        for(String c : cities){
            if(c.length() > 5)
                citiesLength.add(c);
        }
        System.out.println(citiesLength);


    }
}
