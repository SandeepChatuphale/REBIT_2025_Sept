import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class DemoMethodReference {
    public static void main(String[] args) {

        List<String> cities = new ArrayList<>();
        cities.add("Mumbai");
        cities.add("Banglore");

        /*cities.forEach(city -> {
            System.out.println("================");
            System.out.println(city);
            System.out.println("================");
        });*/
        //DemoMethodReference d = new DemoMethodReference();
        //cities.forEach(d::print);
        //cities.forEach(System.out::println);

       // Consumer<String> c = str -> System.out.println(str);
        Consumer<String> c = DemoMethodReference::display;
        cities.forEach(c);
    }
    static void display(String s)
    {
        System.out.println("=========");
        System.out.println(s);
    }



}
