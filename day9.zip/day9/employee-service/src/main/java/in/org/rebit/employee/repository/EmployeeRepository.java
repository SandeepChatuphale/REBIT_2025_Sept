package in.org.rebit.employee.repository;

import in.org.rebit.employee.Employee;

import java.util.Optional;

public interface EmployeeRepository {

    Optional<Employee> findByEmail(String email);
    Employee save(Employee e);

}
