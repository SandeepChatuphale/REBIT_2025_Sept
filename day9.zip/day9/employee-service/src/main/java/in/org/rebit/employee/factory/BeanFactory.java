package in.org.rebit.employee.factory;

import in.org.rebit.employee.repository.EmployeeRepository;
import in.org.rebit.employee.repository.impl.EmployeeRepositoryImpl;
import in.org.rebit.employee.service.impl.EmployeeServiceImpl;

public class BeanFactory {
    private EmployeeRepositoryImpl repo;
    private EmployeeServiceImpl service;
    public BeanFactory(){
        repo = new EmployeeRepositoryImpl();
        service = new EmployeeServiceImpl(repo);
    }
    public EmployeeServiceImpl getService(){
        return service;
    }
}
