package in.org.rebit.employee;

import in.org.rebit.employee.exception.EmployeeNotFoundException;
import in.org.rebit.employee.factory.BeanFactory;
import in.org.rebit.employee.service.EmployeeService;

import java.util.ArrayList;
import java.util.List;

public class EmployeeServiceApplication {
    public static void main(String[] args) throws EmployeeNotFoundException {
        BeanFactory factory = new BeanFactory();
        EmployeeService service = factory.getService();
        int choice = 2;
        switch (choice){
            case 1:
                Employee e = new Employee();
                e.setEmail("sandeep@gmail.com");
                e.setPassword("sandeep");
                List<String> roles = new ArrayList<>();
                roles.add("ROLE_USER");
                roles.add("ROLE_ADMIN");
                e.setRoles(roles);
                service.registerEmployee(e);
                break;
            case 2:
                Employee ee = service.findByEmail("sandeep@gmail.com");
                System.out.println(ee.getRoles());
                break;

        }
    }
}
