package in.org.rebit.bookstore.dao.impl;

import in.org.rebit.bookstore.dao.BookDao;
import in.org.rebit.bookstore.entity.Book;
import in.org.rebit.bookstore.exception.BookNotFoundException;

//responsible for accessing data-store
//typically 4 operations are carried out
//save - Create - C
//select - READ - R
//Update - UPDATE - U
//Delete - DELETE - D
//CRUD - operations
public class BookArrayDaoImpl implements BookDao {

    private Book[] books;
    private int index;

    public BookArrayDaoImpl(){
        this.books = new Book[2];
    }

    public BookArrayDaoImpl(int size){
        this.books = new Book[size];
    }

    public boolean save(Book bookToBeSaved)
    {
        this.books[index] = bookToBeSaved;
        index++;
        return true;
    }
    public boolean deleteById(int id){
        int searchIndex = 0;
        for(Book b : books)
        {
            if(b.getId() == id)
            {
                books[searchIndex] = null;
                return  true;
            }
            searchIndex++;
        }
        return  false;
    }
    public Book findById(int id)throws BookNotFoundException
    {
        for(Book foundBook : books)
        {

            if(foundBook !=null && foundBook.getId() == id)
                return foundBook;
        }
        //generate BookNotFoundException
        BookNotFoundException e = new BookNotFoundException("Book with id " + id +" NOT found");
        throw e;
    }

    public Book update(int id,double newPrice)throws BookNotFoundException
    {
        Book foundBook = findById(id);
        foundBook.setPrice(newPrice);
        return foundBook;
    }

    public Book[] findAll(){
        return this.books;
    }



}
