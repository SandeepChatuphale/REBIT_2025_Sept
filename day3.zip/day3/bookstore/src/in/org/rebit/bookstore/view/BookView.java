package in.org.rebit.bookstore.view;

import in.org.rebit.bookstore.entity.Book;

public class BookView {

    public void showMenu()
    {

        // String menu ="1. Add Book \n"+
        //        "2. Show All  \n"+
        //       "-1. Exit";

        //text block
        String menu = """
                    1. Add Book
                    2. Show All books
                    3. Delete Book
                    4. Find Book
                    5. Update Book
                    -1. Exit
                """;

        printMessage(menu);
        printMessage("Enter your choice");
    }

    //method overloading
    public void printMessage(String message){
        System.out.println(message);
    }
    public void printMessage(String message,MessageType messageType){
        if(messageType == MessageType.SUCCESS)
            printMessage(message);
        else
            System.err.println(message);
    }

    public void printBook(Book b)
    {
        showHeader();
        printMessage(b.getId()+"\t"+b.getTitle()+"\t"+b.getAuthor()+"\t"+b.getPrice());
    }

    private void showHeader()
    {
        printMessage("===============================================");
        printMessage("Id \t title \t author \t price");
        printMessage("===============================================");
    }
}