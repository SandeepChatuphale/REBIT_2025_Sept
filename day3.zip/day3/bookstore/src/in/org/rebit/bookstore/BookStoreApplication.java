package in.org.rebit.bookstore;

import in.org.rebit.bookstore.dao.BookDao;
import in.org.rebit.bookstore.dao.impl.BookArrayDaoImpl;
import in.org.rebit.bookstore.dao.impl.BookCollectionDaoImpl;
import in.org.rebit.bookstore.entity.Book;
import in.org.rebit.bookstore.exception.BookNotFoundException;
import in.org.rebit.bookstore.factory.BeanFactory;
import in.org.rebit.bookstore.view.BookView;
import in.org.rebit.bookstore.view.MessageType;

import java.util.InputMismatchException;
import java.util.Scanner;

public class BookStoreApplication {
    public static void main(String[] args) {
        BeanFactory factory = new BeanFactory();
        Book b1 = null;
        BookView view = new BookView();
        BookDao dao;
        //dao = new BookArrayDao();
        dao = factory.getBookDao();

        Scanner sc = new Scanner(System.in);
        try {

            view.printMessage("number of books registered are " + Book.getCount());


            int choice = 0;
            do {
                try {
                    view.showMenu();
                    choice = sc.nextInt();
                    switch (choice) {
                        case 1:
                            view.printMessage("Adding new book");
                            b1 = new Book("Java", "Kathy", 89);
                            boolean isSaved = dao.save(b1);
                            if (isSaved)
                                view.printMessage("Book Saved");
                            else
                                view.printMessage("Error try again", MessageType.ERROR);
                            break;
                        case 2:
                            view.printMessage("Showing all books");
                            view.printBook(b1);
                            break;
                        case 3:
                            try {
                                boolean isDeleted = dao.deleteById(1);
                                view.printMessage("Book Deleted");
                            }
                            catch (BookNotFoundException e){
                                view.printMessage("Some issue try again", MessageType.ERROR);
                            }
                           
                            break;
                        case 4:
                            int id = 1;
                            try {
                                Book foundBook = dao.findById(id);
                                view.printBook(foundBook);
                            } catch (BookNotFoundException e) {
                                view.printMessage("Sorry Book with id " + id + " not found", MessageType.ERROR);

                            }
                            break;
                        case 5:
                            try {
                                Book updatedBook = dao.update(1, 78);
                                view.printMessage("Book Price updated");
                            } catch (BookNotFoundException e) {
                                view.printMessage("Price NOT Updated", MessageType.ERROR);
                                e.printStackTrace();//TODO log to log file
                            }
                            break;

                        case -1:
                            view.printMessage("Thank you visit again");
                            break;
                        default:
                            view.printMessage("Invalid choice try again", MessageType.ERROR);
                    }
                } catch (InputMismatchException e) {
                    view.printMessage("Please Enter int value ONLY", MessageType.ERROR);
                    sc.next(); //removing wrong i/P from buffer
                }
            } while (choice != -1);
        }
        finally {
            sc.close();
        }
    }
}