package in.org.rebit.bookstore.dao.impl;

import in.org.rebit.bookstore.dao.BookDao;
import in.org.rebit.bookstore.entity.Book;

public class BookCollectionDaoImpl implements BookDao {
    public boolean save(Book bookToBeSaved)
    {
        return true;
    }

    public Book findById(int id){
        return null;
    }

    public boolean deleteById(int id){
        return true;
    }

    public Book update(int id,double newPrice){
        return  null;
    }

    public Book[] findAll(){
        return null;
    }

}
