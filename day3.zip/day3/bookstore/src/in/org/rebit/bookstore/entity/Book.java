package in.org.rebit.bookstore.entity;
public class Book {

    //static OR class variable
    private static int count;

    //instance variables
    private int id;
    private String title;
    private String author;
    private double price;

    private Book() {}

    public Book(String title, String author, double price) {
        count++;
        this.id = count;
        this.title = title;
        this.author = author;
        this.price = price;
    }

    public static int getCount()
    {
        return count;
    }



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
