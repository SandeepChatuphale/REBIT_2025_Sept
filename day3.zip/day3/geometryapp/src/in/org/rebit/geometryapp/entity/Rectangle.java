package in.org.rebit.geometryapp.entity;

public class Rectangle extends Shape {

    private double length;
    private double breadth;


    public Rectangle(double length, double breadth, String color) {
        super(color);
        this.length = length;
        this.breadth = breadth;
    }

    public double calculateArea(){
        return length * breadth;
    }
}
