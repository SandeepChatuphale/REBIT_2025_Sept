package in.org.rebit.geometryapp.entity;

import in.org.rebit.print.Printable;

public class Circle extends Shape implements Printable {
    private double radius;

    public Circle(double radius, String color) {
        super(color);   //invoking constructor of super class
        this.radius = radius;
        System.out.println("In circle constructor");
    }
    @Override
    public double calculateArea(){
        return 3.14*radius*radius;
    }

    @Override
    public void print() {
        draw();
    }
}
