package in.org.rebit.geometryapp;

import in.org.rebit.geometryapp.entity.Circle;
import in.org.rebit.geometryapp.entity.Rectangle;
import in.org.rebit.geometryapp.entity.Shape;

public class GeometryApp {
    public static void main(String[] args) {

        Shape s ;
        //s = new Shape();//ERROR


        s = new Circle(5,"red");
        s.calculateArea();
        drawShape(s);

        s = new Rectangle(5,6,"blue");
        drawShape(s);
    }

    static void drawShape(Shape s) {
        System.out.println(s.calculateArea());
        s.draw();
    }
}