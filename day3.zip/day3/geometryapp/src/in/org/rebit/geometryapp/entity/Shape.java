package in.org.rebit.geometryapp.entity;

public abstract class Shape extends Object {
    protected String color;

    public Shape(String color) {
        super();
        this.color = color;
        System.out.println("In shape constructor");
    }

    public abstract double calculateArea();

    public void draw() {
        System.out.println("Drawing with color " + color);
    }
}
