package in.org.rebit.print;

public interface Printable {
    void print();
}
