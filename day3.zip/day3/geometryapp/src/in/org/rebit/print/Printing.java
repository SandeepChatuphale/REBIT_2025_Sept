package in.org.rebit.print;

public class Printing {

    //api which can print any object passed to it
    //provided that object has a method print()
    static void display(Printable o)
    {
        o.print();
    }

}
