import { Employee } from "./dto/Employee";

let e : Employee = new Employee('a','a');
//console.log(e.email)  //ERROR bcz email is private
console.log(e.password)
e.print()