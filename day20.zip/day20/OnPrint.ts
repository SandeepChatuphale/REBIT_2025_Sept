export interface OnPrint{
    print() : void;
}