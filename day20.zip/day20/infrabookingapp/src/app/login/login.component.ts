import { Component } from '@angular/core';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  //assume these values are entered by user
  email:string = 'sandeep@gmail.com';
  password:string = 'sandeepc';

  //used in template to update GUI
  message=''
  isValid : boolean = true;

  constructor(){
    this.performLogin()
  }
  performLogin(){
    if(this.email == 'sandeep@gmail.com' && this.password == 'sandeep'){
      this.message = "login Success";
    }
    else{
      this.message = "bad credentials"
    }
  }

}
