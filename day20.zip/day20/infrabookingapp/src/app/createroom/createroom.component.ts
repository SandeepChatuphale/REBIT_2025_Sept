import { Component } from '@angular/core';

@Component({
  selector: 'app-createroom',
  standalone: true,
  imports: [],
  templateUrl: './createroom.component.html',
  styleUrl: './createroom.component.css'
})
export class CreateroomComponent {

}
