import { Component } from '@angular/core';
import { Room } from '../../dto/room';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-rooms',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './rooms.component.html',
  styleUrl: './rooms.component.css'
})
export class RoomsComponent {
  rooms : Room[] = [];


  message :string = ''
  isDeleted = false;
  messageColor = '';
  styles = {'color':'red','fontSize':'40px'}

  constructor(){}

  showAllRooms() : void {
    let r1 = new Room(1,'Meeting',12,true);
      let r2 = new Room(2,'Meeting',20,true);
      let r3 = new Room(3,'interview',22,false);
      let r4 = new Room(4,'Training',12,true);
      this.rooms.push(r1);
      this.rooms.push(r2);
      this.rooms.push(r3);
      this.rooms.push(r4);
  }
  deleteRoomById(id:number):void{
      const result =  confirm('are you sure?');
      if(result){
          this.rooms = this.rooms.filter( r => r.id != id )
          this.message = 'Room with id ' + id +' is deleted ';
          this.isDeleted = true;
          this.messageColor = 'red';
           this.styles.color = 'red'
          
      }
      else{
        this.message = 'Cancelled'
        this.isDeleted = false
        this.messageColor = 'green';
        this.styles.color = 'green'
      }

  }

}
