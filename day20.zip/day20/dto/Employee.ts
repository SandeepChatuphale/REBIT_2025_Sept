import { OnPrint } from "../OnPrint";

export class Employee implements OnPrint{
    constructor(private email:string,
                public password:string){}
    print(): void {
        console.log(this.email)
    }
}